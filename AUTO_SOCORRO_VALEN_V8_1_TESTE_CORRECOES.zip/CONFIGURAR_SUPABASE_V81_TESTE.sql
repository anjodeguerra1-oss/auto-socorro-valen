-- V8.1 TESTE. Leia e valide no Supabase antes de executar.
-- Nao exclui tabelas nem altera registros existentes.
create table if not exists public.valen_checklists_offline (
 id uuid primary key,
 auth_user_id uuid not null references auth.users(id),
 sessao_id uuid not null,
 placa text not null,
 criado_em timestamptz not null,
 dados jsonb not null,
 recebido_em timestamptz not null default now()
);
alter table public.valen_checklists_offline enable row level security;
grant select,insert,update on public.valen_checklists_offline to authenticated;
drop policy if exists vc81_checklist_inserir on public.valen_checklists_offline;
create policy vc81_checklist_inserir on public.valen_checklists_offline for insert to authenticated
 with check (auth_user_id=auth.uid() and exists (
  select 1 from public.valen_sessoes_viaturas s
  join public.valen_motorista_vinculos v on v.motorista_id=s.motorista_id
  where s.id=sessao_id and v.auth_user_id=auth.uid() and upper(s.placa)=upper(placa)
 ));
drop policy if exists vc81_checklist_consultar on public.valen_checklists_offline;
create policy vc81_checklist_consultar on public.valen_checklists_offline for select to authenticated
 using (auth_user_id=auth.uid());
-- Retentativa de mesmo ID: impede sobrescrever checklist de outra pessoa.
drop policy if exists vc81_checklist_atualizar on public.valen_checklists_offline;
create policy vc81_checklist_atualizar on public.valen_checklists_offline for update to authenticated
 using (auth_user_id=auth.uid()) with check (auth_user_id=auth.uid());

-- Lista somente chamados destinados ao motorista autenticado.
create or replace function public.valen_meus_chamados()
returns table(id uuid,numero_servico text,origem text,destino text,status text)
language sql security definer set search_path = '' as $$
 select c.id,c.numero_servico::text,c.origem::text,c.destino::text,c.status::text
 from public.valen_chamados_motorista c
 join public.valen_motorista_vinculos v on v.motorista_id=c.motorista_id
 where v.auth_user_id=auth.uid()
 order by c.sent_at desc limit 60
$$;
revoke all on function public.valen_meus_chamados() from public,anon;
grant execute on function public.valen_meus_chamados() to authenticated;

create or replace function public.valen_responder_chamado(p_chamado uuid,p_status text)
returns boolean language plpgsql security definer set search_path = '' as $$
begin
 if p_status not in ('aceito','recusado') then raise exception 'Status invalido'; end if;
 update public.valen_chamados_motorista c set status=p_status
 where c.id=p_chamado and c.status='enviado'
 and exists(select 1 from public.valen_motorista_vinculos v
            where v.motorista_id=c.motorista_id and v.auth_user_id=auth.uid());
 return found;
end $$;
revoke all on function public.valen_responder_chamado(uuid,text) from public,anon;
grant execute on function public.valen_responder_chamado(uuid,text) to authenticated;
-- OBS: confirmar tipos e colunas reais da tabela valen_chamados_motorista
-- antes de executar. O aplicativo NAO sera considerado pronto sem isso.
