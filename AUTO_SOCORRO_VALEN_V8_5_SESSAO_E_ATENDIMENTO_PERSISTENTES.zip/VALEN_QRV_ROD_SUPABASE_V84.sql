-- VALEN V8.4 — QRV/ROD + presença (não modifica nem encerra sessoes existentes)
-- 1) Registrar status do motorista por sessão; 2) somente ele pode atualizar
-- 3) apenas o diretor geral cadastrado pode consultar todas as presenças
create table if not exists public.valen_presencas_motoristas (
  sessao_id uuid primary key references public.valen_sessoes_viaturas(id) on delete cascade,
  motorista_id uuid not null references public.motoristas(id),
  auth_user_id uuid not null references auth.users(id),
  placa text not null,
  status text not null check (status in ('QRV','ROD')),
  atualizado_em timestamptz not null default now()
);
create index if not exists valen_presencas_motoristas_atualizado_idx
  on public.valen_presencas_motoristas(atualizado_em desc);
alter table public.valen_presencas_motoristas enable row level security;
revoke all on table public.valen_presencas_motoristas from anon;
grant select on table public.valen_presencas_motoristas to authenticated;

do $$
declare diretor_id uuid;
begin
  select id into diretor_id from auth.users where lower(email)='anjodeguerra1@gmail.com';
  if diretor_id is null then raise exception 'Conta do Diretor Geral nao encontrada no Auth'; end if;
  if not exists(select 1 from pg_policies where schemaname='public'
    and tablename='valen_presencas_motoristas'
    and policyname='valen_diretor_geral_le_presencas') then
    execute format('create policy valen_diretor_geral_le_presencas
      on public.valen_presencas_motoristas for select to authenticated
      using (auth.uid() = %L::uuid)', diretor_id);
  end if;
end $$;

-- O motorista pode consultar APENAS suas próprias presenças.
do $$ begin
 if not exists(select 1 from pg_policies where schemaname='public'
   and tablename='valen_presencas_motoristas'
   and policyname='valen_motorista_le_propria_presenca') then
   create policy valen_motorista_le_propria_presenca
     on public.valen_presencas_motoristas for select to authenticated
     using (auth_user_id=auth.uid());
 end if;
end $$;

-- Endpoint autorizado para registrar QRV/ROD e renovar o sinal (heartbeat).
-- Valida a sessão aberta + o vínculo do motorista com a conta autenticada.
create or replace function public.valen_registrar_qrv(p_sessao uuid,p_status text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_motorista uuid; v_placa text; v_status text;
begin
  if auth.uid() is null then raise exception 'LOGIN_OBRIGATORIO'; end if;
  v_status:=upper(trim(coalesce(p_status,'')));
  if v_status not in ('QRV','ROD') then raise exception 'STATUS_INVALIDO'; end if;
  select s.motorista_id,s.placa into v_motorista,v_placa
    from public.valen_sessoes_viaturas s
    join public.valen_motorista_vinculos v
      on v.motorista_id=s.motorista_id and v.auth_user_id=auth.uid()
    where s.id=p_sessao and s.encerrada_em is null;
  if v_motorista is null then raise exception 'SESSAO_ENCERRADA_OU_NAO_AUTORIZADA'; end if;
  insert into public.valen_presencas_motoristas(sessao_id,motorista_id,auth_user_id,placa,status,atualizado_em)
  values (p_sessao,v_motorista,auth.uid(),v_placa,v_status,now())
  on conflict(sessao_id) do update
    set status=excluded.status, atualizado_em=now();
end;
$$;
revoke all on function public.valen_registrar_qrv(uuid,text) from public,anon;
grant execute on function public.valen_registrar_qrv(uuid,text) to authenticated;

-- Atenção: o status QRV só significa ONLINE se atualizado_em for recente (até 90 s).
-- O app envia heartbeat a cada 30 s quando está aberto em primeiro plano.
