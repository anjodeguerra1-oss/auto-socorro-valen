-- VALEN CONTROLE / VALEN MOTORISTA: despachos de TESTE, isolados dos atendimentos reais.
-- Projeto: utrahzqzhfqjntsrvbtk. Nao apaga, finaliza ou altera atendimentos existentes.
-- Execute no SQL Editor antes do teste com as duas versoes atualizadas.
CREATE TABLE IF NOT EXISTS public.valen_despachos_teste (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  servico_id text NOT NULL,
  numero_servico text NOT NULL,
  motorista_id uuid NOT NULL REFERENCES public.motoristas(id),
  sessao_id uuid NOT NULL REFERENCES public.valen_sessoes_viaturas(id),
  placa text NOT NULL,
  dados jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'enviado'
    CHECK (status IN ('enviado','aceito','recusado','em_atendimento','finalizado','cancelado')),
  enviado_em timestamptz NOT NULL DEFAULT now(),
  visto_em timestamptz,
  respondido_em timestamptz,
  enviado_por uuid NOT NULL REFERENCES auth.users(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS valen_despachos_teste_um_ativo_por_servico
 ON public.valen_despachos_teste (servico_id)
 WHERE status IN ('enviado','aceito','em_atendimento');
CREATE INDEX IF NOT EXISTS valen_despachos_teste_por_sessao
 ON public.valen_despachos_teste(sessao_id,enviado_em DESC);
ALTER TABLE public.valen_despachos_teste ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.valen_despachos_teste FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.valen_despachos_teste TO authenticated;
DROP POLICY IF EXISTS valen_despachos_teste_diretor_ler ON public.valen_despachos_teste;
CREATE POLICY valen_despachos_teste_diretor_ler ON public.valen_despachos_teste
 FOR SELECT TO authenticated USING (lower(coalesce((SELECT auth.jwt())->>'email','')) = 'anjodeguerra1@gmail.com');
DROP POLICY IF EXISTS valen_despachos_teste_motorista_ler ON public.valen_despachos_teste;
CREATE POLICY valen_despachos_teste_motorista_ler ON public.valen_despachos_teste
 FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.valen_motorista_vinculos v
    WHERE v.auth_user_id=(SELECT auth.uid()) AND v.motorista_id=valen_despachos_teste.motorista_id)
 );

-- Envio e garantido pelo banco: Diretor Geral, motorista e sessao da viatura validos.
CREATE OR REPLACE FUNCTION public.valen_enviar_despacho_teste(
  p_servico_id text,
  p_motorista_id uuid,
  p_sessao_id uuid,
  p_extras jsonb DEFAULT '{}'::jsonb
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_servico jsonb;
  v_sessao record;
  v_status text;
  v_novo public.valen_despachos_teste%ROWTYPE;
BEGIN
  IF (SELECT count(*) FROM auth.users u
       WHERE u.id=auth.uid() AND lower(u.email)='anjodeguerra1@gmail.com') <> 1
  THEN RAISE EXCEPTION 'SOMENTE_DIRETOR_GERAL_PODE_ENVIAR'; END IF;
  IF p_servico_id IS NULL OR p_motorista_id IS NULL OR p_sessao_id IS NULL
  THEN RAISE EXCEPTION 'SERVICO_MOTORISTA_E_SESSAO_OBRIGATORIOS'; END IF;
  SELECT to_jsonb(a) INTO v_servico
    FROM public.atendimentos a WHERE a.id::text=p_servico_id LIMIT 1;
  IF v_servico IS NULL THEN RAISE EXCEPTION 'SERVICO_NAO_ENCONTRADO'; END IF;
  v_status=lower(coalesce(v_servico->>'status',''));
  IF v_status ~ '(conclu|finaliz|cancel)' THEN
    RAISE EXCEPTION 'SERVICO_FINALIZADO_OU_CANCELADO';
  END IF;
  SELECT s.id,s.motorista_id,s.placa INTO v_sessao
    FROM public.valen_sessoes_viaturas s
    WHERE s.id=p_sessao_id AND s.motorista_id=p_motorista_id
      AND s.encerrada_em IS NULL;
  IF NOT FOUND THEN RAISE EXCEPTION 'MOTORISTA_SEM_VIATURA_CONECTADA'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.valen_presencas_motoristas p
    WHERE p.sessao_id=p_sessao_id AND p.status='QRV'
      AND p.atualizado_em > now()-interval '3 minutes'
  ) THEN RAISE EXCEPTION 'MOTORISTA_NAO_ESTA_QRV_ONLINE'; END IF;
  INSERT INTO public.valen_despachos_teste (
    servico_id,numero_servico,motorista_id,sessao_id,placa,dados,enviado_por
  ) VALUES (
    p_servico_id,coalesce(v_servico->>'numero_servico',p_servico_id),
    p_motorista_id,p_sessao_id,v_sessao.placa,
    jsonb_build_object('atendimento',v_servico,'extras',coalesce(p_extras,'{}'::jsonb)),auth.uid()
  ) RETURNING * INTO v_novo;
  RETURN jsonb_build_object('id',v_novo.id,'numero_servico',v_novo.numero_servico,
   'placa',v_novo.placa,'status',v_novo.status,'enviado_em',v_novo.enviado_em);
EXCEPTION WHEN unique_violation THEN
  RAISE EXCEPTION 'SERVICO_JA_ENVIADO_OU_EM_ATENDIMENTO';
END;$$;

-- O aplicativo confirma o recebimento, sem marcar um servico como aceito automaticamente.
CREATE OR REPLACE FUNCTION public.valen_marcar_despacho_recebido(p_despacho_id uuid)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_id uuid;
BEGIN
  UPDATE public.valen_despachos_teste d SET visto_em=COALESCE(d.visto_em,now())
  WHERE d.id=p_despacho_id AND d.status='enviado'
    AND EXISTS (SELECT 1 FROM public.valen_motorista_vinculos v
      WHERE v.auth_user_id=auth.uid() AND v.motorista_id=d.motorista_id)
    AND EXISTS (SELECT 1 FROM public.valen_sessoes_viaturas s
      WHERE s.id=d.sessao_id AND s.encerrada_em IS NULL)
  RETURNING id INTO v_id;
  IF v_id IS NULL THEN RAISE EXCEPTION 'DESPACHO_NAO_AUTORIZADO_OU_JA_RESPONDIDO'; END IF;
  RETURN jsonb_build_object('ok',true);
END;$$;

-- Aceitar ou recusar so pode ser feito pelo proprio motorista e sessao ativa.
CREATE OR REPLACE FUNCTION public.valen_responder_despacho_teste(
  p_despacho_id uuid, p_resposta text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_status text;v_id uuid;v_sessao uuid;
BEGIN
  v_status=lower(trim(coalesce(p_resposta,'')));
  IF v_status NOT IN ('aceito','recusado') THEN RAISE EXCEPTION 'RESPOSTA_INVALIDA'; END IF;
  SELECT d.sessao_id INTO v_sessao FROM public.valen_despachos_teste d
  JOIN public.valen_motorista_vinculos v ON v.motorista_id=d.motorista_id
  JOIN public.valen_sessoes_viaturas s ON s.id=d.sessao_id AND s.encerrada_em IS NULL
  WHERE d.id=p_despacho_id AND v.auth_user_id=auth.uid() AND d.status='enviado'
  FOR UPDATE OF d;
  IF v_sessao IS NULL THEN RAISE EXCEPTION 'DESPACHO_NAO_AUTORIZADO_OU_JA_RESPONDIDO'; END IF;
  IF v_status='aceito' AND (
    SELECT count(*) FROM public.valen_despachos_teste d
    WHERE d.sessao_id=v_sessao AND d.status IN ('aceito','em_atendimento')
  )>=2 THEN RAISE EXCEPTION 'LIMITE_DE_DOIS_SERVICOS_EM_ABERTO'; END IF;
  UPDATE public.valen_despachos_teste
   SET status=v_status, respondido_em=now(), visto_em=COALESCE(visto_em,now())
   WHERE id=p_despacho_id RETURNING id INTO v_id;
  RETURN jsonb_build_object('ok',true,'id',v_id,'status',v_status);
END;$$;

REVOKE ALL ON FUNCTION public.valen_enviar_despacho_teste(text,uuid,uuid,jsonb) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.valen_marcar_despacho_recebido(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.valen_responder_despacho_teste(uuid,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.valen_enviar_despacho_teste(text,uuid,uuid,jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.valen_marcar_despacho_recebido(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.valen_responder_despacho_teste(uuid,text) TO authenticated;
-- Nenhuma sessão, KM ou serviço existente e atualizado por este SQL.
