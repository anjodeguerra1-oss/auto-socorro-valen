package br.com.valen.motorista;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private static final int FILE_REQUEST=100;
  private static final int GPS_REQUEST=871;
  private static final int NOTIFICATION_REQUEST=872;
  private String pendingGpsSession;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    webView = new WebView(this);
    setContentView(webView);
    WebSettings settings=webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(true);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    webView.addJavascriptInterface(new ValenAndroidBridge(),"ValenAndroid");
    webView.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
        Uri uri=req.getUrl();
        if ("file".equals(uri.getScheme()) &&
            "file:///android_asset/index.html".equals(uri.toString())) return false;
        if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
          try {startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
        }
        return true;
      }
    });
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        fileCallback=callback;
        try{startActivityForResult(params.createIntent(),FILE_REQUEST);return true;}
        catch(Exception e){fileCallback=null;return false;}
      }
    });
    webView.loadUrl("file:///android_asset/index.html");
  }

  private boolean hasLocationPermission() {
    return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
      checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
  }
  private void startGps(String json) {
    try {
      JSONObject data=new JSONObject(json);
      if (data.optString("session_id").isEmpty() || data.optString("access_token").isEmpty() ||
        data.optString("refresh_token").isEmpty() || data.optString("auth_user_id").isEmpty()) return;
      ValenSecureStore.save(this,data);
      if (!hasLocationPermission()) {
        pendingGpsSession=json;
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
          Manifest.permission.ACCESS_COARSE_LOCATION},GPS_REQUEST);
        gpsMessage("Permita o GPS para a central localizar a viatura.");
        return;
      }
      launchGpsService();
    } catch(Exception e) {
      gpsMessage("Nao foi possivel ativar o GPS neste aparelho.");
    }
  }
  private void launchGpsService() {
    try {
      Intent i=new Intent(this,ValenTrackingService.class);
      i.setAction(ValenTrackingService.ACTION_START);
      if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
      else startService(i);
      gpsMessage("GPS em segundo plano solicitado. Confira a notificacao permanente.");
      if(Build.VERSION.SDK_INT>=33 &&
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);
      }
    }catch(Exception e) {gpsMessage("GPS nao iniciado: verifique a permissao de localizacao.");}
  }
  private void gpsMessage(String message) {
    if (webView==null) return;
    webView.evaluateJavascript("window.valenGpsNativeMessage?.("+JSONObject.quote(message)+")",null);
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
    super.onRequestPermissionsResult(requestCode,permissions,results);
    if(requestCode==GPS_REQUEST){
      if(hasLocationPermission()){
        pendingGpsSession=null;
        launchGpsService();
      }else{
        gpsMessage("Localizacao nao autorizada. Use Ativar GPS e permita o acesso durante o uso.");
      }
    }
  }
  private class ValenAndroidBridge {
    @JavascriptInterface public void startTracking(String json) {
      runOnUiThread(()->startGps(json));
    }
    @JavascriptInterface public void updateStatus(String status) {
      runOnUiThread(()->{
        try{
          JSONObject data=ValenSecureStore.load(MainActivity.this);
          if(data==null)return;
          data.put("status","QRV".equals(status)?"QRV":"ROD");
          ValenSecureStore.save(MainActivity.this,data);
          if(hasLocationPermission())launchGpsService();
        }catch(Exception ignored){}
      });
    }
    @JavascriptInterface public void updateCredentials(String json) {
      runOnUiThread(()->{
        try {
          JSONObject stored=ValenSecureStore.load(MainActivity.this);
          JSONObject newer=new JSONObject(json);
          if(stored==null||!stored.optString("auth_user_id").equals(newer.optString("auth_user_id")))return;
          for(String key:new String[]{"access_token","refresh_token","expires_at"}){
            if(newer.has(key))stored.put(key,newer.get(key));
          }
          ValenSecureStore.save(MainActivity.this,stored);
        }catch(Exception ignored){}
      });
    }
    @JavascriptInterface public String getCredentials() {
      try {
        JSONObject stored=ValenSecureStore.load(MainActivity.this);
        if(stored==null)return "{}";
        JSONObject sanitized=new JSONObject();
        for(String key:new String[]{"auth_user_id","access_token","refresh_token","expires_at"}){
          if(stored.has(key))sanitized.put(key,stored.get(key));
        }
        return sanitized.toString();
      }catch(Exception e){return "{}";}
    }
    @JavascriptInterface public void centralReleased() {
      runOnUiThread(()->{
        Intent i=new Intent(MainActivity.this,ValenTrackingService.class);
        i.setAction(ValenTrackingService.ACTION_STOP);
        startService(i);
        ValenSecureStore.clear(MainActivity.this);
      });
    }
  }

  @Override protected void onResume(){
    super.onResume();
    if(webView!=null)webView.evaluateJavascript("window.valenNativeResumed?.()",null);
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_REQUEST&&fileCallback!=null){
      fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
      fileCallback=null;
    }
  }
  @Override public void onBackPressed(){
    if(webView!=null){
      webView.evaluateJavascript("(function(){return window.valenNavigateHome && window.valenNavigateHome() ? 'navegou' : 'inicio'})()",result->{
        if(!"\"navegou\"".equals(result))moveTaskToBack(true);
      });
    }else moveTaskToBack(true);
  }
}
