package br.com.valen.motorista;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** Credenciais do plantao cifradas com chave nao exportavel do AndroidKeyStore. */
final class ValenSecureStore {
  private static final String PREFS = "valen_gps_secure_v87";
  private static final String KEY_ALIAS = "valen_gps_auth_aes_v87";
  private ValenSecureStore() {}

  private static SecretKey getKey() throws Exception {
    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
    ks.load(null);
    if (ks.containsAlias(KEY_ALIAS)) return (SecretKey) ks.getKey(KEY_ALIAS, null);
    KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
    generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
      KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
      .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
      .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
      .setKeySize(256).build());
    return generator.generateKey();
  }

  static synchronized void save(Context context, JSONObject data) throws Exception {
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(Cipher.ENCRYPT_MODE, getKey());
    byte[] encrypted = cipher.doFinal(data.toString().getBytes(StandardCharsets.UTF_8));
    JSONObject record = new JSONObject();
    record.put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
    record.put("ct", Base64.encodeToString(encrypted, Base64.NO_WRAP));
    context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      .edit().putString("session", record.toString()).apply();
  }

  static synchronized JSONObject load(Context context) {
    try {
      SharedPreferences preferences=context.getApplicationContext()
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
      String raw = preferences.getString("session", null);
      if (raw == null) return null;
      JSONObject record = new JSONObject(raw);
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE, getKey(),
        new GCMParameterSpec(128, Base64.decode(record.getString("iv"), Base64.NO_WRAP)));
      byte[] plaintext = cipher.doFinal(Base64.decode(record.getString("ct"), Base64.NO_WRAP));
      return new JSONObject(new String(plaintext, StandardCharsets.UTF_8));
    } catch (Exception e) {
      return null; // Nao apagar dados do atendimento por falha de armazenamento.
    }
  }

  static synchronized void clear(Context context) {
    context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      .edit().remove("session").apply();
  }
}
