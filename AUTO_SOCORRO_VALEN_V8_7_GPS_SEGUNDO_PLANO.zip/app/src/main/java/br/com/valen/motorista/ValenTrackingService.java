package br.com.valen.motorista;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Rastreamento iniciado enquanto o app esta visivel, continua com tela bloqueada.
 * Android pode interromper um FGS (restricao de bateria, parada forcada, reboot).
 * Na central, ausencia de heartbeat deve aparecer como SEM COMUNICACAO.
 */
public class ValenTrackingService extends Service implements LocationListener {
  static final String ACTION_START = "br.com.valen.motorista.START_GPS";
  static final String ACTION_STATUS = "br.com.valen.motorista.STATUS_GPS";
  static final String ACTION_STOP = "br.com.valen.motorista.STOP_GPS";
  private static final String CHANNEL = "valen_rastreamento_operacional";
  private static final int NOTIFICATION_ID = 8701;
  private static final String BASE = "https://utrahzqzhfqjntsrvbtk.supabase.co";
  // Chave publicavel, nao e service_role. JWT do motorista e indispensavel.
  private static final String PUBLIC_KEY = "sb_publishable_zE6vt9xRTGsgTZYqZtDTvg_y0WKwAI-";
  private final Object locationLock = new Object();
  private volatile Location latestLocation;
  private LocationManager locationManager;
  private Handler mainHandler;
  private ScheduledExecutorService executor;
  private volatile boolean running = false;
  private volatile boolean gpsRegistered = false;
  private volatile boolean verifying = false;

  @Override public void onCreate() {
    super.onCreate();
    mainHandler = new Handler(Looper.getMainLooper());
    locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
    executor = Executors.newSingleThreadScheduledExecutor();
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent == null ? ACTION_START : intent.getAction();
    if (ACTION_STOP.equals(action)) {
      stopTracking();
      return START_NOT_STICKY;
    }
    JSONObject session = ValenSecureStore.load(this);
    if (session == null || session.optString("session_id").isEmpty()) {
      stopSelf();
      return START_NOT_STICKY;
    }
    if (!hasLocationPermission()) {
      stopSelf();
      return START_NOT_STICKY;
    }
    try {
      ensureForeground(session.optString("placa", "viatura"));
    } catch (Exception e) {
      stopSelf();
      return START_NOT_STICKY;
    }
    registerForLocation();
    if (!running) {
      running = true;
      executor.scheduleWithFixedDelay(new Runnable() {
        @Override public void run() { sendHeartbeatAndPosition(); }
      }, 3, 30, TimeUnit.SECONDS);
    }
    return START_STICKY;
  }

  private boolean hasLocationPermission() {
    return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
      || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
  }

  private void ensureForeground(String plate) {
    NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      manager.createNotificationChannel(new NotificationChannel(CHANNEL,
        "VALEN: localizacao operacional", NotificationManager.IMPORTANCE_LOW));
    }
    Intent open = new Intent(this, MainActivity.class);
    open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
    if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
    PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
    Notification.Builder builder = Build.VERSION.SDK_INT >= 26
      ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
    Notification notification = builder
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setContentTitle("VALEN MOTORISTA · GPS operacional")
      .setContentText("Viatura " + plate + " · acompanhamento da central")
      .setContentIntent(pending)
      .setOngoing(true)
      .setShowWhen(false).build();
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
    } else {
      startForeground(NOTIFICATION_ID, notification);
    }
  }

  private void registerForLocation() {
    if (gpsRegistered || !hasLocationPermission()) return;
    try {
      boolean added = false;
      if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
          30000L, 40f, this, Looper.getMainLooper());
        added = true;
      }
      if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
          30000L, 40f, this, Looper.getMainLooper());
        added = true;
      }
      gpsRegistered = added;
      // Nao enviar lastKnownLocation antigo como coordenada online.
    } catch (SecurityException | IllegalArgumentException ignored) {
      gpsRegistered = false;
    }
  }

  @Override public void onLocationChanged(Location location) {
    if (location == null || !location.hasAccuracy()) return;
    if (location.getAccuracy() > 1500f) return;
    long age = Math.abs(System.currentTimeMillis() - location.getTime());
    if (age > 120000L) return;
    synchronized (locationLock) {
      if (latestLocation == null || location.getTime() >= latestLocation.getTime()) {
        latestLocation = new Location(location);
      }
    }
  }
  @Override public void onStatusChanged(String provider,int status,Bundle extras) {}
  @Override public void onProviderEnabled(String provider) { gpsRegistered=false;registerForLocation(); }
  @Override public void onProviderDisabled(String provider) { gpsRegistered=false; }

  private void sendHeartbeatAndPosition() {
    if (!running || verifying) return;
    verifying = true;
    try {
      JSONObject stored = ValenSecureStore.load(this);
      if (stored == null || stored.optString("session_id").isEmpty()) return;
      ensureFreshToken(stored);
      JSONArray active = asArray(post(stored,"/rest/v1/rpc/valen_minha_sessao",new JSONObject()));
      if (active.length() == 0 || !stored.optString("session_id").equals(active.optJSONObject(0).optString("id"))) {
        mainHandler.post(() -> stopTracking());
        return;
      }
      String status = stored.optString("status", "ROD");
      if (!"QRV".equals(status)) status="ROD";
      JSONObject presence = new JSONObject();
      presence.put("p_sessao",stored.getString("session_id"));
      presence.put("p_status",status);
      try {post(stored,"/rest/v1/rpc/valen_registrar_qrv",presence);} catch (Exception ignored) {
        // GPS e presenca sao independentes; a central nao inventa QRV.
      }
      Location location;
      synchronized (locationLock) {location = latestLocation == null ? null : new Location(latestLocation);}
      if (location != null && System.currentTimeMillis()-location.getTime() <= 120000L) {
        JSONObject payload = new JSONObject();
        payload.put("p_sessao", stored.getString("session_id"));
        payload.put("p_latitude", location.getLatitude());
        payload.put("p_longitude", location.getLongitude());
        payload.put("p_precisao_metros", (double)location.getAccuracy());
        payload.put("p_status", status);
        post(stored,"/rest/v1/rpc/valen_atualizar_gps",payload);
      }
    } catch (Exception ignored) {
      // Ausencia de rede nao libera viatura; central exibe ultima posicao como desatualizada.
    } finally {
      verifying = false;
      if (!gpsRegistered) mainHandler.post(() -> registerForLocation());
    }
  }

  private static JSONArray asArray(String response) throws Exception {
    if (response.trim().startsWith("[")) return new JSONArray(response);
    JSONArray output = new JSONArray();
    if (response.trim().startsWith("{")) output.put(new JSONObject(response));
    return output;
  }

  private void ensureFreshToken(JSONObject session) throws Exception {
    long expiry=session.optLong("expires_at",0);
    long now=System.currentTimeMillis()/1000L;
    if (expiry>now+120) return;
    String refresh=session.optString("refresh_token","");
    if (refresh.isEmpty()) throw new Exception("Sessao sem token de renovacao");
    JSONObject body = new JSONObject();body.put("refresh_token",refresh);
    String result=rawPost("/auth/v1/token?grant_type=refresh_token",body.toString(),PUBLIC_KEY);
    JSONObject token = new JSONObject(result);
    session.put("access_token",token.getString("access_token"));
    session.put("refresh_token",token.getString("refresh_token"));
    session.put("expires_at",now+token.optLong("expires_in",3600));
    ValenSecureStore.save(this,session);
  }

  private String post(JSONObject session, String path,JSONObject data) throws Exception {
    return rawPost(path,data.toString(),session.getString("access_token"));
  }
  private String rawPost(String path,String body,String bearer) throws Exception {
    HttpURLConnection c = (HttpURLConnection)new URL(BASE+path).openConnection();
    try {
      c.setRequestMethod("POST");c.setDoOutput(true);
      c.setConnectTimeout(12000);c.setReadTimeout(12000);
      c.setRequestProperty("apikey",PUBLIC_KEY);
      c.setRequestProperty("Authorization","Bearer "+bearer);
      c.setRequestProperty("Content-Type","application/json");
      byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
      try(OutputStream out=c.getOutputStream()){out.write(bytes);}
      int code=c.getResponseCode();
      InputStream stream=code<400?c.getInputStream():c.getErrorStream();
      ByteArrayOutputStream buffer=new ByteArrayOutputStream();
      if(stream!=null){try(InputStream in=stream){byte[] chunk=new byte[8192];int n;
        while((n=in.read(chunk))!=-1){buffer.write(chunk,0,n);
          if(buffer.size()>131072)break;}
      }}
      String message=new String(buffer.toByteArray(),StandardCharsets.UTF_8);
      if(code>=400)throw new Exception("HTTP "+code+" "+message);
      return message;
    } finally {c.disconnect();}
  }

  private void stopTracking() {
    running=false;
    ValenSecureStore.clear(this);
    try {locationManager.removeUpdates(this);}catch(Exception ignored){}
    gpsRegistered=false;
    stopForeground(true);
    stopSelf();
  }
  @Override public void onDestroy() {
    running=false;
    if (executor!=null)executor.shutdownNow();
    try {locationManager.removeUpdates(this);}catch(Exception ignored){}
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent intent) {return null;}
}
