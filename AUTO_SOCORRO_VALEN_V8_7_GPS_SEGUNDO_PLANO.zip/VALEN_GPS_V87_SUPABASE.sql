-- VALEN MOTORISTA V8.7: recebimento de GPS real das viaturas.
-- Use no projeto Supabase utrahzqzhfqjntsrvbtk.
-- Nao deleta, zera nem encerra sessoes, cadastros, KM ou atendimentos.

CREATE TABLE IF NOT EXISTS public.valen_gps_viaturas (
  motorista_id uuid PRIMARY KEY REFERENCES public.motoristas(id),
  placa text NOT NULL,
  latitude double precision NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude double precision NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  precisao_metros double precision,
  status text NOT NULL DEFAULT 'SEM_STATUS',
  atualizado_em timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.valen_gps_viaturas
  ADD COLUMN IF NOT EXISTS sessao_id uuid;

CREATE INDEX IF NOT EXISTS idx_valen_gps_viaturas_horario
  ON public.valen_gps_viaturas (atualizado_em DESC);

ALTER TABLE public.valen_gps_viaturas ENABLE ROW LEVEL SECURITY;

-- Apenas usuarios autenticados podem consultar; as politicas RLS ainda filtram os dados.
GRANT SELECT ON public.valen_gps_viaturas TO authenticated;

-- Autoriza Diretor Geral identificado pelo UUID do Supabase Auth.
DO $$
DECLARE v_diretor uuid;
BEGIN
  SELECT id INTO v_diretor FROM auth.users
   WHERE lower(email) = 'anjodeguerra1@gmail.com';
  IF v_diretor IS NULL THEN
    RAISE EXCEPTION 'Conta do Diretor Geral nao encontrada no Auth';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='valen_gps_viaturas'
      AND policyname='valen_diretor_ler_gps_v87'
  ) THEN
    EXECUTE format(
      'CREATE POLICY valen_diretor_ler_gps_v87 ON public.valen_gps_viaturas
       FOR SELECT TO authenticated USING (auth.uid() = %L::uuid)', v_diretor
    );
  END IF;
END $$;

-- Recebe GPS SOMENTE da viatura realmente assumida pelo motorista da sessao.
CREATE OR REPLACE FUNCTION public.valen_atualizar_gps(
  p_sessao uuid,
  p_latitude double precision,
  p_longitude double precision,
  p_precisao_metros double precision,
  p_status text
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_motorista uuid;
  v_placa text;
  v_status text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'LOGIN_OBRIGATORIO';
  END IF;
  IF p_latitude IS NULL OR p_longitude IS NULL
    OR NOT (p_latitude BETWEEN -90 AND 90)
    OR NOT (p_longitude BETWEEN -180 AND 180) THEN
    RAISE EXCEPTION 'COORDENADAS_INVALIDAS';
  END IF;
  IF p_precisao_metros IS NOT NULL
    AND (p_precisao_metros < 0 OR p_precisao_metros > 1500) THEN
    RAISE EXCEPTION 'PRECISAO_INVALIDA';
  END IF;
  v_status := upper(trim(coalesce(p_status,'')));
  IF v_status NOT IN ('QRV','ROD') THEN
    RAISE EXCEPTION 'STATUS_INVALIDO';
  END IF;

  SELECT s.motorista_id,s.placa
  INTO v_motorista,v_placa
  FROM public.valen_sessoes_viaturas s
  JOIN public.valen_motorista_vinculos v
    ON v.motorista_id=s.motorista_id
   AND v.auth_user_id=auth.uid()
  WHERE s.id=p_sessao AND s.encerrada_em IS NULL;

  IF v_motorista IS NULL THEN
    RAISE EXCEPTION 'SESSAO_ENCERRADA_OU_NAO_AUTORIZADA';
  END IF;

  INSERT INTO public.valen_gps_viaturas
   (motorista_id,placa,latitude,longitude,precisao_metros,status,atualizado_em,sessao_id)
  VALUES
   (v_motorista,v_placa,p_latitude,p_longitude,p_precisao_metros,v_status,now(),p_sessao)
  ON CONFLICT (motorista_id) DO UPDATE SET
    placa=excluded.placa,
    latitude=excluded.latitude,
    longitude=excluded.longitude,
    precisao_metros=excluded.precisao_metros,
    status=excluded.status,
    atualizado_em=excluded.atualizado_em,
    sessao_id=excluded.sessao_id;

  RETURN jsonb_build_object('gravado',true,'placa',v_placa,'atualizado_em',now());
END $$;

REVOKE ALL ON FUNCTION public.valen_atualizar_gps(uuid,double precision,double precision,double precision,text)
  FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.valen_atualizar_gps(uuid,double precision,double precision,double precision,text)
  TO authenticated;

-- Confere criacao da funcao sem divulgar localizacao.
SELECT 'GPS V8.7 preparado' AS resultado;
